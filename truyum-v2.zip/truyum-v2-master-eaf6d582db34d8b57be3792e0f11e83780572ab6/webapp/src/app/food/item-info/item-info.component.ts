import { Component, OnInit, Input, Output } from '@angular/core';
import { Food } from 'src/app/food/food';
import { EventEmitter } from '@angular/core';
import { AuthService } from 'src/app/food/services/auth.service';
import { DatePipe, getLocaleTimeFormat } from '@angular/common';
import { parse } from 'querystring';
import { Router } from '@angular/router';
import { ItemEditComponent } from '../item-edit/item-edit.component';
import { HttpHeaders } from '@angular/common/http';
import { UserAuthServiceService } from 'src/app/food/services/user-auth-service.service';
import { MenuitemService } from '../services/menuitem.service';



@Component({
  selector: 'app-item-info',
  templateUrl: './item-info.component.html',
  styleUrls: ['./item-info.component.css']
})
export class ItemInfoComponent implements OnInit {

  @Input() food: Food;
  itemAdded = false;
  cus = false;
  myDate = new Date(Date.parse(Date()));
  @Output() addedToCart: EventEmitter<number> = new EventEmitter<number>();
  da: string;
  dat: string;
  daa: string[];
  daaa: string[];
  role:string;
  constructor(private authService: AuthService, private authenticationService: UserAuthServiceService, private router: Router, private menuService: MenuitemService, public datepipe: DatePipe) {

  }
  ngOnInit() {
    return this.food.active;
    // this.food={
    //   id: 1, name: "Sandwich", price: 99, active: true, dateOfLaunch: new Date("2017-03-15"),
    //   category: "Main Course", freeDelivery: true,
    //   imageUrl: "https://source.unsplash.com/4nHpGXcgq7I/800x600"
    // }
  }
  onAddToCart(id: number) {
    if (!this.authService.loggedIn) {
      // id = this.food.id;
      this.authService.setItemId(id);
      this.router.navigate(['/login']);
    } else {
      console.log(id);
      this.addedToCart.emit(id);
      // this.role=this.authService.getUserId();
      // this.menuService.addCartItem(this.role,id);
      this.itemAdded = true;
      setTimeout(() => {
        this.itemAdded = false;
      }, 1000);
      return false;
    }
  }
  // customer() {
  //   // this.da=this.datepipe.transform(this.food.dateOfLaunch, 'dd/MM/yyyy').toString();
  //   // this.dat=this.datepipe.transform(this.myDate, 'dd/MM/yyyy').toString();
  //   // this.daa=this.da.split('/');
  //   // this.daaa=this.dat.split('/');
  //   if (this.food.active) {
  //     this.cus = true;
  //     console.log(this.daaa);
  //     return this.cus;
  //   } else {
  //     this.cus = false;
  //     return this.cus;
  //   }
  // }
  ifAdmin() {
    return this.authService.isAdminUser() && this.authService.loggedIn;
  }
  ifLogged() {
    return this.authService.loggedIn;
  }

  active(){
    if(this.food.active){
      return true;
    }
    else{
      return false;
    }
  }
}
