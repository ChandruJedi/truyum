import { Component, OnInit } from '@angular/core';
import { Food } from 'src/app/food/food';
import { FoodService } from '../services/food.service';

import { Subject, Observable } from 'rxjs';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {
 
  
  foodFilter: Food[];
  foods: Food[];
  searchKey: string;
  constructor(private foodService: FoodService) {
    }
    search(event: any) {
      // let filter = this.searchKey.toLocaleLowerCase();
      // this.foodFilter = this.foods.filter(
      //   (iFood: Food) => iFood.name.toLocaleLowerCase().indexOf(filter) != -1
      // );
     this.foodService.filter.next({title: event.target.value});
   }

  ngOnInit() {
//         this.foods=[{
//       id: 1, name: "Sandwich", price: 99, active: true, dateOfLaunch: new Date("2017-03-15"),
//       category: "Main Course", freeDelivery: true,
//       imageUrl: "https://source.unsplash.com/4nHpGXcgq7I/800x600"
//     },
//     {
//       id: 2, name: "Burger", price: 129, active: true, dateOfLaunch: new Date("2017-12-23"),
//       category: "Main Course", freeDelivery: false,
//       imageUrl: "https://source.unsplash.com/4hgYULBzVEE/800x600"
//     },
//     {
//       id: 3, name: "Pizza", price: 149, active: true, dateOfLaunch: new Date("2017-08-21"),
//       category: "Main Course", freeDelivery: false,
//       imageUrl: "https://source.unsplash.com/HGPlnmepMAA/800x600"
//     },
//     {
//       id: 4, name: "French Fries", price: 57, active: false, dateOfLaunch: new Date("2017-03-02"),
//       category: "Starters", freeDelivery: true,
//       imageUrl: "https://source.unsplash.com/Uf0aVyl5C70/800x600"
//     },
//     {
//       id: 5, name: "Chocolate Brownie", price: 32, active: true, dateOfLaunch: new Date("2014-11-02"),
//       category: "Dessert", freeDelivery: true,
//       imageUrl: "https://source.unsplash.com/1rqk6XVnw44/800x600"
    
//   }
// ];
  }

}
