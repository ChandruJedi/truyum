import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { FoodService } from '../services/food.service';
import { ActivatedRoute, Router, Params } from '@angular/router';
import { Food } from '../food';
import { MenuitemService } from '../services/menuitem.service';

@Component({
  selector: 'app-item-edit',
  templateUrl: './item-edit.component.html',
  styleUrls: ['./item-edit.component.css']
})
export class ItemEditComponent implements OnInit {
  editForm: FormGroup;
  editFood = false;
  error: string;
  constructor(private foodService: FoodService, private menuItemService: MenuitemService, private route: ActivatedRoute, private router: Router) { }

  ngOnInit() {
    this.editForm = new FormGroup({
      'id':new FormControl(null),
      'name': new FormControl(null, [Validators.required, Validators.maxLength(200)]),
      'imageUrl': new FormControl(null, [Validators.required]),
      'price': new FormControl(null, [Validators.required, Validators.pattern('^[0-9]+$')]),
      'dateOfLaunch': new FormControl(null),
      'freeDelivery': new FormControl(null),
      'active': new FormControl(null, Validators.required),
      'category': new FormControl(null, Validators.required),
    });
    this.route.params.subscribe((params: Params) => {
      const id= params['id'];
      this.menuItemService.getMenuItem(id).subscribe((food:Food) => {
        if (food) {
          this.editForm.patchValue({
            id:id,
            name: food.name,
            imageUrl: food.imageUrl,
            price: food.price,
            dateOfLaunch: food.dateOfLaunch,
            active: food.active,
            freeDelivery: food.freeDelivery,
            category: food.category
          });
        }
        // else {
        //   this.router.navigate(['Not-Found']);
        // }
        
      });
    })
  }
      // this.foodService.getFood(id).subscribe((food: Food) => {
      //   if (food) {
      //     this.editForm.patchValue({
      //       name: food.name,
      //       imageUrl: food.imageUrl,
      //       price: food.price,
      //       dateOfLaunch: food.dateOfLaunch,
      //       active: food.active?'yes':'no',
      //       freeDelivery: food.freeDelivery,
      //       category: food.category
      //     });
      //   } 
      //   else {
      //     this.router.navigate(['Not-Found']);
      //   }

      // });

  onSubmit(food:any) {
      this.editFood = true;
      console.log("done");
    this.menuItemService.modifyMenuItem(food).subscribe(data => {
        console.log('MenuItem update successful.');
        this.error = '';
      },
      error => {
        console.log(error);
        this.error = error.error.message;
        if (error.error.errors != null) {
          this.error = error.error.errors[0];
        }
      });
    }
}
