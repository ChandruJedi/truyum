import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CartService } from 'src/app/food/services/cart.service';
import { AuthService } from 'src/app/food/services/auth.service';
import { LoginComponent } from 'src/app/site/login/login.component';
import { UserAuthServiceService } from 'src/app/food/services/user-auth-service.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  main:string;
  constructor(private router: Router, private name: UserAuthServiceService, private authService: AuthService) { 
    // const username=user.form.username;
    // return username;
  }
  authenticated(){
    return this.authService.loggedIn;
  }
  isAdmin(){
    return this.authService.isAdmin;
  }
  getUser(){
    return this.authService.userAuthenticated;
  }
  getName(){
    //console.log(this.name.getUserName())
    return this.name.getUserName();
  }
  signOut(){
    // this.cartService.clearCart();
    this.authService.logOut();
    this.router.navigate([this.authService.navUrl]);
  }
  
  ngOnInit() {
    
  }

}
