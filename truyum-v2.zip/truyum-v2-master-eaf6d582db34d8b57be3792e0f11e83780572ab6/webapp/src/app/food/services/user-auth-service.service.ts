import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { NgForm, Form } from '@angular/forms';
import { User } from '../../site/user';

@Injectable({
  providedIn: 'root'
})
export class UserAuthServiceService {

  private authenticationApiUrl = 'http://localhost:8083/authenticate';
  private token: string;
  role: string;
  username: string;
  firstname: string;
  lastname: string;
  password: string;
  mainName:string;
  id: number;
  constructor(private httpClient: HttpClient) { }
  authenticate(user: string, password: string): Observable<any>{
    this.role=user;
    this.mainName=user;
    let credentials=btoa(user + ':' + password);
    let headers = new HttpHeaders();
    headers = headers.set('Authorization', 'Basic ' + credentials);
    return this.httpClient.get(this.authenticationApiUrl, {headers});
  }
  public setToken(token: string) {
    this.token = token;
  }
  // public setRole(role:string){
  //   this.role=role;
  // }
  public getRole(){
    return this.role;
  }
  public getUserName(){
    return this.mainName;
  }
  public getToken() {
    return this.token;
  }

}
