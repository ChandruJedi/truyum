import { Injectable } from '@angular/core';
import { Cart } from '../../shopping/cart/cart';
import { FoodService } from './food.service';
import { Food } from '../food';
import { v4 as uuid } from 'uuid';
import { environment } from 'src/environments/environment';
import { UserAuthServiceService } from './user-auth-service.service';
import { HttpClient } from '@angular/common/http';



@Injectable({
  providedIn: 'root'
})
export class CartService {
  // private baseU=environment.baseUrl;
  // role:string;
  // cart: Cart = { items: null, total: 0 };

  // constructor(private foodService: FoodService, private httpClient: HttpClient, private cartService: CartService, private userService: UserAuthServiceService) { }
  // getCart() { 
  //   // this.role=this.userService.getRole();
    
  //   return this.cart; 
  // }
  // getAllCartItems(){
  //   this.role=this.userService.getRole();
  //   return this.httpClient.get(this.baseU+'/carts'+this.role);

  // }
  // addToCart(id: number, quantity: number) {
  //   console.log("adding");
  //   this.foodService.getFood(id).subscribe((addFood: Food) => {
  //     const uid = uuid();
  //     if (this.cart.items === null) {
  //       this.cart.items = [{ itemId: uid, food: addFood, quantity }];
  //       this.cart.total = addFood.price;
  //     } else {
  //       this.cart.items.push({ itemId: uid, food: addFood, quantity });
  //       this.cart.total += addFood.price;
  //     }
  //   });
  // }
  // removeCart(id: string) {
  //   const index = this.cart.items.findIndex(item => item.itemId === id);
  //   const removeItem = this.cart.items.splice(index, 1)[0];
  //   this.cart.total -= removeItem.food.price;
  // }
  // clearCart() {
  //   this.cart.items = null;
  //   this.cart.total = 0;
  // }
}
