import { Injectable } from '@angular/core';
import { Food } from '../food';
import { Subject, Observable, Observer, observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { AuthService } from './auth.service';
import { map } from 'rxjs/operators';


@Injectable({
  providedIn: 'root'
})
export class FoodService {
  configUrl = 'assets/food-list.json';
  filter = new Subject();
  foodFilter: Food[];
  finalFoods: Food[];
  foods: Food[];
  cusFood: Food[];
  food: Food;
  status: string;
  boo = "yes";
  dad = true;
  // =[{
  //   id: 1, name: "Sandwich", price: 99, active: true, dateOfLaunch: new Date("2017-03-15"),
  //   category: "Main Course", freeDelivery: true,
  //   imageUrl: "https://source.unsplash.com/4nHpGXcgq7I/800x600"
  // },
  // {
  //   id: 2, name: "Burger", price: 129, active: true, dateOfLaunch: new Date("2017-12-23"),
  //   category: "Main Course", freeDelivery: false,
  //   imageUrl: "https://source.unsplash.com/4hgYULBzVEE/800x600"
  // },
  // {
  //   id: 3, name: "Pizza", price: 149, active: true, dateOfLaunch: new Date("2017-08-21"),
  //   category: "Main Course", freeDelivery: false,
  //   imageUrl: "https://source.unsplash.com/HGPlnmepMAA/800x600"
  // },
  // {
  //   id: 4, name: "French Fries", price: 57, active: false, dateOfLaunch: new Date("2017-03-02"),
  //   category: "Starters", freeDelivery: true,
  //   imageUrl: "https://source.unsplash.com/Uf0aVyl5C70/800x600"
  // },
  // {
  //   id: 5, name: "Chocolate Brownie", price: 32, active: true, dateOfLaunch: new Date("2014-11-02"),
  //   category: "Dessert", freeDelivery: true,
  //   imageUrl: "https://source.unsplash.com/1rqk6XVnw44/800x600"

  // }
  // ];

  constructor(private link: HttpClient, private authService: AuthService) {
  }
  getFoodItems(): Food[] {
    return this.foods;
  }
  getFoods(): Observable<any> {
    return this.link.get(this.configUrl);

  }
  // getCust(): Observable<any>{
  
  //   return this.link.get(this.configUrl)
  //   .pipe(map((res:Response) => res.json()))
  //   .pipe(map(x => x.foods.filter(y => y.dateOfLaunch< new Date())))
  // }
  getFood(id: number): Observable<any> {
    return Observable.create((observer: Observer<Food>) => {
      this.getFoods().subscribe((foods: Food[]) => {
        if (this.authService.isAdmin) {
          const item = foods.find(food => food.id == id);
          observer.next(item);
        } else {
          // if(foods.dateOfLaunch<new Date() && foods.active){
            
          const item = foods.find(food => food.id == id);
          observer.next(item);
          // }
        }
      });
    });
  }
  // if(this.food.active && this.food.dateOfLaunch<new Date())
}
