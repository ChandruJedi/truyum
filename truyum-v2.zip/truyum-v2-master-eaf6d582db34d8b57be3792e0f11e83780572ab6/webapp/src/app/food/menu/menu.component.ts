import { Component, OnInit, Input } from '@angular/core';
import { Food } from 'src/app/food/food';
import { FoodService } from '../services/food.service';
import { Subject, Observable } from 'rxjs';
import { CartService } from 'src/app/food/services/cart.service';
import { RouterEvent } from '@angular/router';
import { AuthService } from 'src/app/food/services/auth.service';
import { MenuitemService } from '../services/menuitem.service';
import { UserAuthServiceService } from 'src/app/food/services/user-auth-service.service';


@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.css']
})
export class MenuComponent implements OnInit {
  role:string;
  foods: Food[];
  tempList: Food[];
  constructor(private foodService: FoodService, private userAuth: UserAuthServiceService,private menuItemService: MenuitemService, private authService: AuthService) {
    //if (!this.authService.isAdmin) {
      this.foods = foodService.getFoodItems();
    //} 
    // else {
    //   this.foods=foodService.getCust();
    // }
  }

  ngOnInit() {
    this.menuItemService.getAllMenuItems().subscribe(data => {
      this.foods = data;
      this.tempList=data;
      // this.userAuth.setRole("user");
    });
  
    //     this.foods=[{
    //       id: 1, name: "Sandwich", price: 99, active: true, dateOfLaunch: new Date("2017-03-15"),
    //       category: "Main Course", freeDelivery: true,
    //       imageUrl: "https://source.unsplash.com/4nHpGXcgq7I/800x600"
    //     },
    //     {
    //       id: 2, name: "Burger", price: 129, active: true, dateOfLaunch: new Date("2017-12-23"),
    //       category: "Main Course", freeDelivery: false,
    //       imageUrl: "https://source.unsplash.com/4hgYULBzVEE/800x600"
    //     },
    //     {
    //       id: 3, name: "Pizza", price: 149, active: true, dateOfLaunch: new Date("2017-08-21"),
    //       category: "Main Course", freeDelivery: false,
    //       imageUrl: "https://source.unsplash.com/HGPlnmepMAA/800x600"
    //     },
    //     {
    //       id: 4, name: "French Fries", price: 57, active: false, dateOfLaunch: new Date("2017-03-02"),
    //       category: "Starters", freeDelivery: true,
    //       imageUrl: "https://source.unsplash.com/Uf0aVyl5C70/800x600"
    //     },
    //     {
    //       id: 5, name: "Chocolate Brownie", price: 32, active: true, dateOfLaunch: new Date("2014-11-02"),
    //       category: "Dessert", freeDelivery: true,
    //       imageUrl: "https://source.unsplash.com/1rqk6XVnw44/800x600"

    //   }
    // ];
  //   this.foodService.getFoods().subscribe((food: Food[]) => {
  //     this.tempList = [...food];
  //     this.foods = [...food];
  //   }
  //   );
    this.foodService.filter.subscribe((obj: { title: string }) => {
      if (obj.title !== '') {
        const result = this.tempList.filter(food => food.name.toLowerCase().includes(obj.title.toLowerCase()));
        this.foods = result ? result : [];
      } else {
        this.foods = [...this.tempList];
      }
    });
  }
  addFoodToCart(id: number) {
    console.log(id);
    this.menuItemService.addCartItem(id).subscribe();
    // this.router.url('/cart');
  }
}