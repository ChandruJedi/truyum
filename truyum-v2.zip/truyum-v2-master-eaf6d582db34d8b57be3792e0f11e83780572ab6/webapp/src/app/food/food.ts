export interface Food{
  // myDate: any;
    id: number;
    name: string;
    dateOfLaunch: Date;
    price: number;
    freeDelivery: boolean;
    active: boolean;
    imageUrl: string;
    category: string;
}