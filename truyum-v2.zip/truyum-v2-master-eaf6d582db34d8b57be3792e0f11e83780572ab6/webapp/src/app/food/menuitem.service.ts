import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { Food } from './food';
import { AuthService } from '../site/auth.service';
// import { AuthGuardService } from '../site/auth-guard.service';
import { environment } from 'src/environments/environment';
import { Cart } from '../shopping/cart/cart';
import { User } from '../site/user';
import { UserAuthServiceService } from './services/user-auth-service.service';

@Injectable({
  providedIn: 'root'
})
export class MenuitemService {
  private menuUrl = 'http://localhost:8083/menu-items';
  // private baseU=environment.baseUrl;
  private baseU='http://localhost:8083/carts';
  userId: string;
  constructor(private httpClient: HttpClient, private authenticationService: UserAuthServiceService ) { }
  public getAllMenuItems(): Observable<Food[]>{
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + this.authenticationService.getToken()
      })
    };
    return this.httpClient.get<Food[]>(this.menuUrl,httpOptions);
  }
  public getMenuItem(id:number):Observable<any>{
    //this.httpClient.get<Food[]>(this.menuUrl+'[id]');
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + this.authenticationService.getToken()
      })
    };
    return this.httpClient.get<Food>(this.menuUrl+"/"+id,httpOptions);
  }
  modifyMenuItem(food:Food):Observable<void> {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + this.authenticationService.getToken()
      })
    };
    return this.httpClient.put<void>(this.menuUrl,food,httpOptions);
  }
  addCartItem(menuItemId:number):Observable<void>{
    this.userId=this.authenticationService.getRole();
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + this.authenticationService.getToken()
      })
    };
    return this.httpClient.post<void>(this.baseU+"/"+this.userId+"/"+menuItemId,{},httpOptions);
  }

  getAllCartItems():Observable<any> {
    this.userId=this.authenticationService.getRole();
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + this.authenticationService.getToken()
      })
    };
    console.log(this.userId);
    return this.httpClient.get<Cart>(this.baseU+"/"+this.userId,httpOptions);
  }

  deleteCartItem(userId:string, menuItemId:number):Observable<void>{
    // this.userId=this.authenticationService.getRole();
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + this.authenticationService.getToken()
      })
    };
    return this.httpClient.delete<void>(this.baseU+"/"+this.userId+"/"+menuItemId,httpOptions);
  }

  // public addUser(user:User):Observable<void>{
  //   // const httpOptions = {
  //   //   headers: new HttpHeaders({
  //   //     'Content-Type': 'application/json',
  //   //     'Authorization': 'Bearer ' + this.authenticationService.getToken()
  //   //   })
  //   // };
  //   return this.httpClient.post<void>(this.baseU+"/users",user);
  // }
}
