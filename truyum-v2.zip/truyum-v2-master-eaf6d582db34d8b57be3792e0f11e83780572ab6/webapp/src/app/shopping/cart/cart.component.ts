import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Subject, Observable, Observer } from 'rxjs';
import { CartService } from '../../food/services/cart.service';
import { Cart } from './cart';
import { AuthService } from 'src/app/food/services/auth.service';
import { UserAuthServiceService } from 'src/app/food/services/user-auth-service.service';
import { MenuitemService } from 'src/app/food/services/menuitem.service';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {
  cart: Cart;
  role:string;
  userId:string;
  error: any;
  isEmpty: boolean;
  constructor(private cartService:CartService,private userService: UserAuthServiceService, private authService: AuthService, private menuItemService: MenuitemService) { 
    this.menuItemService.getAllCartItems().subscribe(data => {
      this.cart = data;
      console.log(this.cart);
    }); 
  }
  ngOnInit() {
    // this.role=this.authService.getUserId();
    // this.cartService.getAllCartItems();
  }
  onRemoveItem(itemId: number) {
    console.log(itemId)
    this.userId=this.userService.getRole();
    this.menuItemService.deleteCartItem(this.userId,itemId).subscribe(data => {
      this.menuItemService.getAllCartItems().subscribe( (cart) => {
        if(cart){
          console.log(cart);
          this.cart = cart;
        }
      },
      (error) => {
        console.log(error.error.message);
        this.cart.total=0;
        this.error = error.error.message;
        this.isEmpty=true;
      })
      
    });
  }
  // ifLogin(){
  //   return this.authService.isAdminUser() && this.authService.loggedIn;
  // }
  // ifCust(){
  //   return this.authService.loggedIn;
  // }
}
