export interface User{
    username:string;
    id: number;
    firstname:string;
    lastname:string;
    role:string;
    accessToken:string;
    password?:string;
}