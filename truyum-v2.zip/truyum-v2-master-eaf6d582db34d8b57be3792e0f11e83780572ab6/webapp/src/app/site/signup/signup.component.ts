import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { User } from '../user';
import { Router } from '@angular/router';
import { UserService } from '../../food/services/user.service';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
  editSign: FormGroup;
  // form: NgForm;
  user: User;
  userPresent: boolean=false;
  error: string;
  signupformValidation: boolean;
  constructor(private userService: UserService, private router: Router) { }

  ngOnInit() {
    this.editSign = new FormGroup({
      // 'id':new FormControl(null),
      firstname: new FormControl(null),
      lastname: new FormControl(null),
      username: new FormControl(null),
      password: new FormControl(null),
      cpassword:new FormControl(null)
      // 'id': new FormControl(null),
      // 'accessToken': new FormControl(null),
      // 'role': new FormControl(null),
    });
  }
  onSubmit(){
    // this.user=this.editSign.value;
    // console.log(this.editSign);
    // this.userService.addUser(this.user).subscribe(
    //   (data)=>{
    //     this.router.navigate(['/login']);
    //   },
    //   (errorData)=>{
    //     this.error=errorData.error.errorMessage;
    //     this.userPresent=true;
    //   }
    //)
    this.user=this.editSign.value;
    console.log(this.user);
    if (this.editSign.value.password != this.editSign.value.cpassword) {
      this.signupformValidation = true;
    }
    else {
      this.userService.addUser(this.user).subscribe(
        (response) => {
          this.router.navigate(['/login']);
        },
        (responseError) => {
          this.error = responseError.error.errorMessage;
          this.userPresent=true;
        }
       );
    }
   
    }
  }
