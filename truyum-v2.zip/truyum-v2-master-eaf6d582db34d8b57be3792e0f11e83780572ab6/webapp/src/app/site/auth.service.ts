import { Injectable } from '@angular/core';
// import { UserService } from './user.service';
import { User } from './user';
import { environment } from 'src/environments/environment';
import { HttpHeaders,HttpClient } from '@angular/common/http';
import { UserService } from '../food/services/user.service';
// import { HttpClient } from 'selenium-webdriver/http';
@Injectable({
  providedIn: 'root'
})
export class AuthService {
  loggedIn=false;
  isAdmin=false;
  isCustomer=false;
  accessToken:string;
  itemId: number;
  userId:any;
  navUrl='/';
  //baseUrl=environment.baseUrl;
  userAuthenticated:User;
  constructor(private userService: UserService) { }
  logIn(username: string, password:string){
    this.userService.authenticate(username,password).subscribe((user:User)=>{
      if(user){
        this.loggedIn=true;
        this.userAuthenticated=user;
        this.isAdmin=user.role==='Admin';
        this.isCustomer=user.role==='Customer';
      }
    });
    // let credentials = btoa(username + ":" +password);
    // let headers = new HttpHeaders();
    // headers = headers.set('Authorization', 'Basic ' + credentials);
    // return this.httpClient.get(this.navUrl, {headers});
  }

  setItemId(id: number){
    console.log(id);
    // this.navUrl='/login';
    this.itemId=id;
  }
  getItemId(){
    return this.itemId;
  }
  // getUserId(){
  //   if(this.isCustomer){
  //     return "user";
  //   } 
  // }
  logOut(){
    this.navUrl='/';
    this.loggedIn=false;
  }
  isAdminUser(){
    return this.isAdmin;
  }
}
