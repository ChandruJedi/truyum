INSERT INTO menu_item(me_name, me_price, me_active, me_date_of_launch, me_category, me_free_delivery,me_imageUrl)
VALUES ('Sandwich', 99, 'Yes', '2017-03-15', 'Main Course', 'Yes','https://source.unsplash.com/4nHpGXcgq7I/800x600'),
('Burger', 129, 'Yes', '2017-12-23', 'Main Course', 'No','https://source.unsplash.com/4hgYULBzVEE/800x600'),
('Pizza', 149, 'Yes', '2017-08-21', 'Main Course', 'No','https://source.unsplash.com/HGPlnmepMAA/800x600'),
('French Fries', 57, 'No', '2017-07-02', 'Starters', 'Yes','https://source.unsplash.com/Uf0aVyl5C70/800x600'),
('Chocolate Brownie', 32, 'Yes', '2022-11-02', 'Dessert', 'Yes','https://source.unsplash.com/1rqk6XVnw44/800x600');

INSERT INTO role(ro_name)
VALUES ('ADMIN'),
('USER');

INSERT INTO user(us_name,us_password)
VALUES ('admin', '$2a$10$R/lZJuT9skteNmAku9Y7aeutxbOKstD5xE5bHOf74M2PHZipyt3yK'),
('user', '$2a$10$R/lZJuT9skteNmAku9Y7aeutxbOKstD5xE5bHOf74M2PHZipyt3yK');

INSERT INTO user_role (ur_us_id,ur_ro_id)
VALUES (1,1),
(2,2);

 
 



