package com.cognizant.truyum.service;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.truyum.TruyumConstants;
import com.cognizant.truyum.dto.CartDTO;
import com.cognizant.truyum.exception.CartEmptyException;
import com.cognizant.truyum.model.MenuItem;
import com.cognizant.truyum.model.User;
import com.cognizant.truyum.repository.MenuItemRepository;
import com.cognizant.truyum.repository.UserRepository;

@Service
public class CartService {
//	@Autowired CartDaoCollectionImpl cartDao;
	@Autowired UserRepository userRepository;
	@Autowired MenuItemRepository menuItemRepository;
	@Transactional
	public void addCartItem(String username, int menuItemId){
		User user1=userRepository.findByUsername(username);
		TruyumConstants.LOGGER.debug("cart ser");
		MenuItem items=menuItemRepository.findById(menuItemId).get();
		TruyumConstants.LOGGER.debug("cart ser out 1");
		TruyumConstants.LOGGER.debug(items.toString());
//		TruyumConstants.LOGGER.debug(user1.toString());
		if(user1.getMenuList()==null) {
			user1.setMenuList(new ArrayList<MenuItem>());
		}
		user1.getMenuList().add(items);
		TruyumConstants.LOGGER.debug("cart ser out 2");
		userRepository.save(user1);
		TruyumConstants.LOGGER.debug("cart ser out 3");
	}
	@Transactional
	public CartDTO getAllCartItems(String username) throws CartEmptyException {
		CartDTO cartDTO = new CartDTO();
		List<MenuItem> list = userRepository.getMenuItems(username);
		if (list == null || list.isEmpty()) {
			throw new CartEmptyException();
		} else {
			cartDTO.setMenuItemList(list);
			cartDTO.setTotal(userRepository.getCartTotal(username));
			return cartDTO;
		}
	}
	
	public void deleteCartItem(String user, int menuItemId) {
		User users=userRepository.findByUsername(user);
		List<MenuItem> list=users.getMenuList();
		for(MenuItem menuItem:list) {
			if(menuItem.getId()==menuItemId) {
				list.remove(menuItem);
				break;
			}
		}
		users.setMenuList(list);
		userRepository.save(users);
	}
}
