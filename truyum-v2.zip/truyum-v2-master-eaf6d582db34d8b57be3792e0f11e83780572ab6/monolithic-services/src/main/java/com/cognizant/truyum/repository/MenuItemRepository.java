package com.cognizant.truyum.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cognizant.truyum.model.MenuItem;

@Repository
public interface MenuItemRepository extends JpaRepository<MenuItem,Integer> {
	@Query(value = "SELECT * FROM menu_item WHERE me_active = true AND me_date_of_launch<=CURRENT_DATE", nativeQuery = true)
	List<MenuItem> getMenuItemListCustomer();
	@Query(value = "SELECT * FROM menu_item", nativeQuery = true)
	List<MenuItem> getMenuItemListAdmin();
}
