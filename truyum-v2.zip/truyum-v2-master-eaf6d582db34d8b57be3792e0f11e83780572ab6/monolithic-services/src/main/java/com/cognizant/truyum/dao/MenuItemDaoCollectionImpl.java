package com.cognizant.truyum.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.cognizant.truyum.TruyumConstants;
import com.cognizant.truyum.model.MenuItem;
import com.cognizant.truyum.util.DateUtil;

//@Component
//public class MenuItemDaoCollectionImpl implements MenuItemDao {
//	static ArrayList<MenuItem> menuItemList;
//	public MenuItemDaoCollectionImpl() {
//		ApplicationContext context = new ClassPathXmlApplicationContext("truyum.xml");
//		menuItemList = context.getBean("menuItems",ArrayList.class);
//		TruyumConstants.LOGGER.debug("in super");
//		for(MenuItem menuItem:menuItemList) {
//			TruyumConstants.LOGGER.debug(menuItem.toString());
//		}
//	}
//	/**Creates a list of Menu Items in the Admin section
//	 * @return The created list of Menu Items
//	 */
////	@Override
////	public List<MenuItem> getMenuItemListAdmin() {
////		return menuItemList;
////	}
//	@Override
//	public List<MenuItem> getMenuItemListAdmin() {
//		TruyumConstants.LOGGER.debug("in get admin");
//		return menuItemList;
//	}
//	
//	/**Creates a list of Menu Items in the Customer section
//	 * @return The Menu Items which satisfies the active and launch date condition.
//	 */
////	@Override
////	public List<MenuItem> getMenuItemListCustomer() {
////		List<MenuItem> menuItemListCustomer = new ArrayList<MenuItem>();
////		for (MenuItem menuItem : menuItemList) {
////			Date launchDate = menuItem.getDateOfLaunch();
////			Date today = new Date();
////			boolean isActive = menuItem.isActive();
////			if ((launchDate.before(today) || launchDate.equals(today)) && isActive) {
////				menuItemListCustomer.add(menuItem);
////			}
////		}
////		TruyumConstants.LOGGER.debug("in get cust");
////		return menuItemListCustomer;
////	}
////	@Override
////	public void modifyMenuItem(MenuItem menuItem) {
////		// TODO Auto-generated method stub
////		
////	}
//
//	
//	/**Modifies the Menu Item in the list
//	 * @param menuItem
//	 */
//	@Override
//	public void modifyMenuItem(MenuItem menuItem) {
//		for (int i = 0; i < menuItemList.size(); i++) {
//			if (menuItemList.get(i).equals(menuItem)) {
//				menuItemList.set(i, menuItem);
//				TruyumConstants.LOGGER.debug("dao "+menuItemList.toString());
//				break;
//			}
//		}
//	}
//	
//	/**Gets the Menu Item from the list
//	 * @param menuItemId
//	 * @return
//	 */
//	@Override
//	public MenuItem getMenuItem(long menuItemId) {
//		MenuItem menuItem = null;
//		for (MenuItem item : menuItemList) {
//			if (item.getId() == menuItemId) {
//				menuItem = item;
//				break;
//			}
//		}
//		return menuItem;
//	}
//
//}
