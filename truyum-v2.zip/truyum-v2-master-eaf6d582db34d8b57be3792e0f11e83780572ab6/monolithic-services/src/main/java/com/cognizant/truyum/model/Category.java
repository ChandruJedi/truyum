package com.cognizant.truyum.model;

public class Category {
	int id;
	String name;
}

