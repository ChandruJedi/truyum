//package com.cognizant.truyum.dao;
//
//import java.util.ArrayList;
//import java.util.HashMap;
//import java.util.List;
//
//import org.springframework.stereotype.Component;
//
//import com.cognizant.truyum.model.Cart;
//import com.cognizant.truyum.model.MenuItem;
//import com.cognizant.truyum.dao.CartDao;
//import com.cognizant.truyum.exception.CartEmptyException;
//
///**
// * @author 805972
// *
// */
//@Component
//public class CartDaoCollectionImpl implements CartDao {
//
//	private static HashMap<String, Cart> userCarts;
//
//	/**Creates a new Hashmap for the User Carts
//	 * 
//	 */
//	public CartDaoCollectionImpl() {
//		if (userCarts == null) {
//			userCarts = new HashMap<>();
//		}
//	}
//	
//	/**Adds the list of Menu Items to the Carts
//	 * 
//	 * @param userId
//	 * @param menuItemId
//	 */
//	@Override
//	public void addCartItem(String userId, long menuItemId) {
//		MenuItemDao menuItemDao = new MenuItemDaoCollectionImpl();
//		MenuItem menuItem = menuItemDao.getMenuItem(menuItemId);
//		if (userCarts.containsKey(userId)) {
//			Cart cart = userCarts.get(userId);
//			List<MenuItem> menuItemList = cart.getMenuItemList();
//			menuItemList.add(menuItem);
//		} else {
//			Cart cart = new Cart(new ArrayList<>(), 0.0);
//			List<MenuItem> menuItemList = cart.getMenuItemList();
//			menuItemList.add(menuItem);
//			userCarts.put(userId, cart);
//		}
//	}
//	
//	/**Gets the list of all the cart items
//	 * @param userId
//	 * @returns Returns all the cart items and the total price
//	 * @throws CartEmptyException
//	 */
//	@Override
//	public Cart getAllCartItems(String userId) throws CartEmptyException{
//		if (userCarts.containsKey(userId)) {
//			Cart cart = userCarts.get(userId);
//			List<MenuItem> cartItems = cart.getMenuItemList();
//			double total = 0;
//			if (cartItems.isEmpty()) {
//				throw new CartEmptyException();
//			} 
//				for (MenuItem cartItem : cartItems) {
//					total += cartItem.getPrice();
//					cart.setTotal(total);
//				}
//				return cart;
//			
//		} else {
//			throw new CartEmptyException();
//		}
//	}
//	
//	/**Removes the cart items in the particular Id 
//	 * @param userId
//	 * @param menuItemId
//	 */
//	@Override
//	public void deleteCartItem(String userId, long menuItemId) {
//		Cart cart = userCarts.get(userId);
//		List<MenuItem> cartItems = cart.getMenuItemList();
//		for (MenuItem cartItem : cartItems) {
//			if (cartItem.getId() == menuItemId) {
//				cartItems.remove(cartItem);
//				break;
//			}
//		}
//	}
//
//}
//
