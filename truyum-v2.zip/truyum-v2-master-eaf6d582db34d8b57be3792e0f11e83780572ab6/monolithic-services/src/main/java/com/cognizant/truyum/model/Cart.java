//package com.cognizant.truyum.model;
//
//import java.util.Set;
//
//import javax.persistence.Column;
//import javax.persistence.Entity;
//import javax.persistence.FetchType;
//import javax.persistence.GeneratedValue;
//import javax.persistence.GenerationType;
//import javax.persistence.Id;
//import javax.persistence.ManyToOne;
//import javax.persistence.OneToMany;
//import javax.persistence.Table;
//import javax.validation.constraints.NotNull;
//import javax.validation.constraints.Positive;
//
///**
// * @author 805972
// *
// */
//@Entity
//@Table(name = "cart")
//public class Cart {
//	@Id
//	@GeneratedValue(strategy = GenerationType.IDENTITY)
//	@Column(name = "dp_id")
//	@NotNull
//	@Positive
//	private int id;
//	@ManyToOne(mappedBy = "cart", fetch = FetchType.EAGER)
//	private Set<MenuItem> menuItemList;
//	private double total=0;
//
//	/**
//	 * @param menuItemList
//	 * @param total
//	 */
//	public Cart(Set<MenuItem> menuItemList, double total) {
//		super();
//		this.menuItemList = menuItemList;
//		this.total = total;
//	}
//	
//	
//	public Cart() {
//		super();
//		// TODO Auto-generated constructor stub
//	}
//
//
//	/**
//	 * @return Returns Menu Item list
//	 */
//	public Set<MenuItem> getMenuItemList() {
//		return menuItemList;
//	}
//
//	/**Sets the Menu Item list
//	 * @param menuItemList
//	 */
//	public void setMenuItemList(Set<MenuItem> menuItemList) {
//		this.menuItemList = menuItemList;
//	}
//
//	public double getTotal() {
//		return total;
//	}
//
//	public void setTotal(double total) {
//		this.total = total;
//	}
//
//	@Override
//	public int hashCode() {
//		final int prime = 31;
//		int result = 1;
//		result = prime * result + ((menuItemList == null) ? 0 : menuItemList.hashCode());
//		long temp;
//		temp = Double.doubleToLongBits(total);
//		result = prime * result + (int) (temp ^ (temp >>> 32));
//		return result;
//	}
//
//	@Override
//	public boolean equals(Object obj) {
//		if (this == obj)
//			return true;
//		if (obj == null)
//			return false;
//		if (getClass() != obj.getClass())
//			return false;
//		Cart other = (Cart) obj;
//		if (menuItemList == null) {
//			if (other.menuItemList != null)
//				return false;
//		} else if (!menuItemList.equals(other.menuItemList))
//			return false;
//		if (Double.doubleToLongBits(total) != Double.doubleToLongBits(other.total))
//			return false;
//		return true;
//	}
//	
//	@Override
//	public String toString() {
//		return "Cart [menuItemList=" + menuItemList + ", total=" + total + "]";
//	}
//	
//}
