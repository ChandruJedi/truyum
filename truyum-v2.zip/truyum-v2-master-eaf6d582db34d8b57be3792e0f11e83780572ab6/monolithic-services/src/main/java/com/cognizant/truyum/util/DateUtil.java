package com.cognizant.truyum.util;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * @author 805972
 *
 */
public class DateUtil {
	
	/**Converts the input date to the format "dd/MM/yyyy"
	 * @param date
	 * @return The parsed date of the given parameter
	 */
	public static Date convertToDate(String date) {
		Date parsedDate = null;
		try {
			SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
			dateFormat.setLenient(false);
			parsedDate = dateFormat.parse(date);
		} catch (ParseException parseException) {
			parseException.printStackTrace();
			throw new RuntimeException("Error in parsing date");
		}
		return parsedDate;
	}
	
}
