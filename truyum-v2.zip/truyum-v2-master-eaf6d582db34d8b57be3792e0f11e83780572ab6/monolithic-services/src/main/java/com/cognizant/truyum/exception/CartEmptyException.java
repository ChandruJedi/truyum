package com.cognizant.truyum.exception;

/**
 * @author 805972
 *
 */
@SuppressWarnings("serial")
public class CartEmptyException extends Exception {

	public CartEmptyException() {
		super();
	}

}
