package com.cognizant.truyum.dao;

import java.util.List;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.cognizant.truyum.model.MenuItem;

/**
 * @author 805972
 *
 */
public interface MenuItemDao {
	
	/**Creates a list of Menu Items in the Admin section
	 * @return The created list of Menu Items
	 */
	public List<MenuItem> getMenuItemListAdmin();

	/**Creates a list of Menu Items in the Customer section
	 * @return The Menu Items which satisfies the active and launch date condition.
	 */
	public List<MenuItem> getMenuItemListCustomer();

	/**Modifies the Menu Item in the list
	 * @param menuItem
	 */
	public void modifyMenuItem(MenuItem menuItem);

	/**Gets the Menu Item from the list
	 * @param menuItemId
	 * @return
	 */
	public MenuItem getMenuItem(long menuItemId);
	
}
