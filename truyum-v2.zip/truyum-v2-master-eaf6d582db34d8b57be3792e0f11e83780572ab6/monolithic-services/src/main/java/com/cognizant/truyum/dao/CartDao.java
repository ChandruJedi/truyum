//package com.cognizant.truyum.dao;
//
//import com.cognizant.truyum.exception.CartEmptyException;
//import com.cognizant.truyum.model.Cart;
//
///**
// * @author 805972
// *
// */
//public interface CartDao {
//	/**Adds the list of Menu Items to the Carts
//	 * 
//	 * @param userId
//	 * @param menuItemId
//	 */
//	public void addCartItem(String userId, long menuItemId);
//
//	/**Gets the list of all the cart items
//	 * @param userId
//	 * @returns Returns all the cart items and the total price
//	 * @throws CartEmptyException
//	 */
//	public Cart getAllCartItems(String userId) throws CartEmptyException;
//
//	/**Removes the cart items in the particular Id 
//	 * @param userId
//	 * @param menuItemId
//	 */
//	public void deleteCartItem(String userId, long menuItemId);
//}
