package com.cognizant.truyum.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.cognizant.truyum.TruyumConstants;
import com.cognizant.truyum.dao.MenuItemDao;
//import com.cognizant.truyum.dao.MenuItemDaoCollectionImpl;
import com.cognizant.truyum.model.MenuItem;
import com.cognizant.truyum.repository.MenuItemRepository;

@Service
public class MenuItemService {
//	private MenuItemDaoCollectionImpl menuItemDao;
	@Autowired MenuItemRepository menuItemRepository;
//	@Autowired
//	public void setMenuItemDao(MenuItemDaoCollectionImpl menuItemDao) {
//		TruyumConstants.LOGGER.debug("Inside Truyum Service");
//		this.menuItemDao = menuItemDao;
//	}
//	public List<MenuItem> getMenuItemListCustomer(){
//		return menuItemDao.getMenuItemListCustomer();
//	}
	public List<MenuItem> getMenuItemListCustomer(){
		return menuItemRepository.getMenuItemListCustomer();
	}
	public List<MenuItem> getMenuItemListAdmin(){
		return menuItemRepository.getMenuItemListAdmin();
	}
	public void modifyMenuItem(MenuItem menuItem) {
		TruyumConstants.LOGGER.debug("ser "+menuItem.toString());
//		menuItemDao.modifyMenuItem(menuItem);
		menuItemRepository.save(menuItem);
	}
	public MenuItem getMenuItem(int menuItemId) {
		return menuItemRepository.findById(menuItemId).get();
	}
	
	
}
