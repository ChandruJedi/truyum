package com.cognizant.truyum.dto;

import java.util.List;
import java.util.Set;

import com.cognizant.truyum.model.MenuItem;

/**
 * @author 805972
 *
 */
public class CartDTO {
	
	private List<MenuItem> menuList;
	private double total=0;

	/**
	 * @param menuList
	 * @param total
	 */
	public CartDTO(List<MenuItem> menuList, double total) {
		super();
		this.menuList = menuList;
		this.total = total;
	}
	
	
	public CartDTO() {
		super();
		// TODO Auto-generated constructor stub
	}


	/**
	 * @return Returns Menu Item list
	 */
	public List<MenuItem> getMenuItemList() {
		return menuList;
	}

	/**Sets the Menu Item list
	 * @param menuItemList
	 */
	public void setMenuItemList(List<MenuItem> menuItemList) {
		this.menuList = menuItemList;
	}

	public double getTotal() {
		return total;
	}

	public void setTotal(double total) {
		this.total = total;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((menuList == null) ? 0 : menuList.hashCode());
		long temp;
		temp = Double.doubleToLongBits(total);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CartDTO other = (CartDTO) obj;
		if (menuList == null) {
			if (other.menuList != null)
				return false;
		} else if (!menuList.equals(other.menuList))
			return false;
		if (Double.doubleToLongBits(total) != Double.doubleToLongBits(other.total))
			return false;
		return true;
	}
	
	@Override
	public String toString() {
		return "Cart [menuItemList=" + menuList + ", total=" + total + "]";
	}
	
}

