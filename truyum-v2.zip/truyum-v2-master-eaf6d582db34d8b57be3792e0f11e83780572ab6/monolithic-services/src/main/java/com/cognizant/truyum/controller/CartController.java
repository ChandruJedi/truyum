package com.cognizant.truyum.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.truyum.TruyumConstants;
import com.cognizant.truyum.dto.CartDTO;
import com.cognizant.truyum.exception.CartEmptyException;
import com.cognizant.truyum.service.CartService;

@RestController
@RequestMapping("/carts")
public class CartController {
	@Autowired CartService cartService;
	@PostMapping("/{user}/{menuItemId}")
	public void addCartItem(@PathVariable String user, @PathVariable int menuItemId){
		TruyumConstants.LOGGER.debug("cart con");
		cartService.addCartItem(user, menuItemId);
	}
	@GetMapping("/{user}")
	public  CartDTO getAllCartItems(@PathVariable String user) throws CartEmptyException{
		 TruyumConstants.LOGGER.info("inside Controller"+user);
		return this.cartService.getAllCartItems(user);
	}
	
	@DeleteMapping("/{user}/{menuItemId}")
	public void deleteCartItem(@PathVariable String user, @PathVariable int menuItemId) {
		cartService.deleteCartItem(user, menuItemId);
	}
}
