package com.cognizant.truyum.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.truyum.TruyumConstants;
import com.cognizant.truyum.model.MenuItem;
import com.cognizant.truyum.security.UserDetailService;
import com.cognizant.truyum.service.MenuItemService;

@RestController
@RequestMapping("/menu-items")
public class MenuItemController {
	@Autowired 
	private MenuItemService menuItemService;
//	@Autowired private  InMemoryUserDetailsManager inMemoryUserDetailsManager;
	@Autowired private UserDetailService userDetailService;
	public void setMenuItemService(MenuItemService menuItemService) {
		TruyumConstants.LOGGER.debug("Inside menulist Control");
		this.menuItemService=menuItemService;
	}
	@GetMapping
	public List<MenuItem> getAllMenuItem(){
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		String user = authentication.getName();
				
		TruyumConstants.LOGGER.debug(user);
		
		if (!user.equals("anonymousUser")) {
			UserDetails userDetails = userDetailService.loadUserByUsername(user);
			String role = userDetails.getAuthorities().toArray()[0].toString();
			TruyumConstants.LOGGER.debug("ROLE OF LOGGED IN USER -> " + role);
			if (role.equals("ADMIN")) {
				return menuItemService.getMenuItemListAdmin();
			} else {
				return menuItemService.getMenuItemListCustomer();
			}
		} else {
			return menuItemService.getMenuItemListCustomer();
		}
	}
	
	@GetMapping("/{id}")
	public MenuItem getMenuItem(@PathVariable int id) {
		return menuItemService.getMenuItem(id);
	}
	
	@PutMapping
	public void modifyMenuItem(@RequestBody MenuItem menuItem){
		TruyumConstants.LOGGER.debug("contro "+menuItem.toString());
		menuItemService.modifyMenuItem(menuItem);
	}
}
