package com.cognizant.truyum;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class TruyumConstants {

	public static final Logger LOGGER= LoggerFactory.getLogger(TruyumApplication.class);
}
