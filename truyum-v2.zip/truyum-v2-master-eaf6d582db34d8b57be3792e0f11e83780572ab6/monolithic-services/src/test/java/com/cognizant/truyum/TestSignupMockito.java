package com.cognizant.truyum;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;

import java.util.HashSet;
import java.util.Set;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.userdetails.UserDetails;

import com.cognizant.truyum.model.Role;
import com.cognizant.truyum.model.User;
import com.cognizant.truyum.repository.UserRepository;
import com.cognizant.truyum.security.UserDetailService;

public class TestSignupMockito {

	private static Logger LOGGER = LoggerFactory.getLogger(TestSignupMockito.class);

	@Test
	public void testSignUp() {
		UserRepository repository = Mockito.mock(UserRepository.class);
		when(repository.findByUsername("user")).thenReturn(createUser());
		UserDetailService service = new UserDetailService(repository);
		UserDetails user = service.loadUserByUsername("user");
		String expected = "$2a$10$R/lZJuT9skteNmAku9Y7aeutxbOKstD5xE5bHOf74M2PHZipyt3yK";
		assertEquals(expected, user.getPassword());
	}

//	@Test
	public void mockTestLoadUserByUserNameNull() {
		UserRepository repository = Mockito.mock(UserRepository.class);
		when(repository.findByUsername("usr")).thenReturn(null);
		UserDetailService service = new UserDetailService(repository);
		try {
			UserDetails user = service.loadUserByUsername("usr");
			LOGGER.debug("User={}", user);
		} catch (Exception e) {
			assertTrue(true);
		}
	}

	public User createUser() {
		User user = new User();
		user.setId(2);
		user.setUsername("newUser");
		user.setPassword("$2a$10$R/lZJuT9yiteNmAku9Y7aeutxbOKstD5xE5bHOf74M2PHZipyt3yK");
		Set<Role> roles = new HashSet<>();
		Role role = new Role();
		role.setId(1);
		role.setName("USER");
		roles.add(role);
		user.setRole(roles);
		return user;
	}
}
